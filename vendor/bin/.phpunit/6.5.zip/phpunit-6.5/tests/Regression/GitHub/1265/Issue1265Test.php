<?php
use PHPUnit\Framework\TestCase;

class Issue1265Test extends TestCase
{
    public function testTrue()
    {
        $this->assertTrue(true);
    }
}
